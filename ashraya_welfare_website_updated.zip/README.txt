Ashraya Welfare and Educational Society website

Files: index.html

To publish/update on GitHub Pages, upload index.html to the root of your repository and choose to replace the existing file, then commit the changes.

The contact form prepares an email using the visitor's device email app; it does not send automatically or store messages. The visitor must press Send in their email app.
